package com.utility.billing;

public final class BillingCalculator {

    // ---- Task 1: slab limits (units, kWh) and rate per unit (Rs.) ----
    public static final int SLAB_1_MAX = 100;     //   0 - 100
    public static final int SLAB_2_MAX = 200;     // 101 - 200
    public static final int SLAB_3_MAX = 400;     // 201 - 400, slab 4 is above 400
    public static final double RATE_1 = 3.00;
    public static final double RATE_2 = 4.50;
    public static final double RATE_3 = 6.00;
    public static final double RATE_4 = 7.50;

    // ---- Task 3: surcharge and rebate rules ----
    public static final double LATE_SURCHARGE_RATE = 0.02;  // 2% of (energy + fixed)
    public static final double ONLINE_REBATE_RATE  = 0.01;  // 1% of energy charge

    private BillingCalculator() { }

    /** Task 1 - telescopic slab billing: each slab is charged only for the units inside it. */
    public static double energyCharge(int units) {
        if (units < 0) {
            throw new IllegalArgumentException("Units cannot be negative: " + units);
        }
        double charge;
        if (units <= SLAB_1_MAX) {
            charge = units * RATE_1;
        } else if (units <= SLAB_2_MAX) {
            charge = SLAB_1_MAX * RATE_1 + (units - SLAB_1_MAX) * RATE_2;
        } else if (units <= SLAB_3_MAX) {
            charge = SLAB_1_MAX * RATE_1 + (SLAB_2_MAX - SLAB_1_MAX) * RATE_2
                   + (units - SLAB_2_MAX) * RATE_3;
        } else {
            charge = SLAB_1_MAX * RATE_1 + (SLAB_2_MAX - SLAB_1_MAX) * RATE_2
                   + (SLAB_3_MAX - SLAB_2_MAX) * RATE_3 + (units - SLAB_3_MAX) * RATE_4;
        }
        return round2(charge);
    }

    /** Shows how the units were split across the slabs, e.g. "100 x 3.00 + 50 x 4.50". */
    public static String slabBreakdown(int units) {
        int[] limits = {SLAB_1_MAX, SLAB_2_MAX, SLAB_3_MAX, Integer.MAX_VALUE};
        double[] rates = {RATE_1, RATE_2, RATE_3, RATE_4};
        StringBuilder sb = new StringBuilder();
        int lower = 0;
        for (int i = 0; i < limits.length && units > lower; i++) {
            int inSlab = Math.min(units, limits[i]) - lower;
            if (sb.length() > 0) sb.append(" + ");
            sb.append(inSlab).append(" x ").append(String.format("%.2f", rates[i]));
            lower = limits[i];
        }
        return sb.length() == 0 ? "0" : sb.toString();
    }

    /** Task 2 - fixed monthly charge per category using a switch expression. */
    public static double fixedCharge(Category category) {
        return switch (category) {
            case DOMESTIC   -> 50.00;
            case COMMERCIAL -> 150.00;
            case INDUSTRIAL -> {
                double demandCharge = 350.00;   // contract-demand charge
                double meterRent    = 50.00;    // CT-meter rent
                yield demandCharge + meterRent;
            }
        };
    }

    /** Task 3 - complete bill with late-payment surcharge and online-payment rebate. */
    public static Bill computeBill(int units, Category category, int daysLate, boolean paidOnline) {
        double energy = energyCharge(units);
        double fixed  = fixedCharge(category);

        double surcharge = daysLate > 0 ? round2((energy + fixed) * LATE_SURCHARGE_RATE) : 0.0;

        /*
         * Operator precedence for the rebate expression below (highest first):
         *   1.  *   energy * ONLINE_REBATE_RATE          multiplicative
         *   2.  <=  daysLate <= 0                        relational
         *   3.  &&  paidOnline && (daysLate <= 0)        conditional AND
         *   4.  ?:  (condition) ? (product) : 0.0        ternary
         *   5.  =   assignment is done last              (right-associative)
         * So it is read as:
         *   rebate = ((paidOnline && (daysLate <= 0)) ? (energy * ONLINE_REBATE_RATE) : 0.0);
         * Pitfall avoided: "energy + fixed + daysLate > 0 ? ..." would parse as
         *   ((energy + fixed + daysLate) > 0) ? ...  because + binds tighter than >.
         */
        double rebate = paidOnline && daysLate <= 0 ? energy * ONLINE_REBATE_RATE : 0.0;
        rebate = round2(rebate);

        double net = round2(energy + fixed + surcharge - rebate);
        return new Bill(units, category, energy, fixed, surcharge, rebate, net);
    }

    /** Rounds to paise; Math.round returns long, so 100.0 keeps the division in double. */
    static double round2(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
