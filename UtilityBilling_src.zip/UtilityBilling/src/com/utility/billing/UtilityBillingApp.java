package com.utility.billing;

import java.time.Month;
import java.time.format.TextStyle;
import java.util.Locale;
import java.util.Scanner;

public class UtilityBillingApp {

    public static void main(String[] args) {
        printAnnualStatement();
        readMeterReadings(new Scanner(System.in));
    }

    /** Task 4 (a) - for loop over 12 months to produce the annual statement. */
    static void printAnnualStatement() {
        int[] units        = {85, 100, 101, 150, 200, 201, 320, 400, 401, 510, 275, 90};
        int[] daysLate     = { 0,   0,   0,   6,   0,   0,  12,   0,   0,   0,   3,  0};
        boolean[] online   = {true, true, false, false, true, true,
                              false, true, true, false, false, true};
        Category category  = Category.DOMESTIC;

        System.out.println("================ 12-MONTH STATEMENT : Consumer DOM-104417 (DOMESTIC) ================");
        System.out.printf("%-5s %6s %10s %8s %10s %8s %11s  %s%n",
                "Month", "Units", "Energy", "Fixed", "Surcharge", "Rebate", "Net (Rs.)", "Payment");
        System.out.println("-".repeat(86));

        int totalUnits = 0;
        double totalNet = 0.0, totalSurcharge = 0.0, totalRebate = 0.0;
        for (int m = 0; m < 12; m++) {
            Bill b = BillingCalculator.computeBill(units[m], category, daysLate[m], online[m]);
            String month = Month.of(m + 1).getDisplayName(TextStyle.SHORT, Locale.ENGLISH);
            String payment = daysLate[m] > 0 ? "LATE " + daysLate[m] + "d"
                                             : (online[m] ? "Online" : "Counter");
            System.out.printf("%-5s %6d %10.2f %8.2f %10.2f %8.2f %11.2f  %s%n", month, b.units(),
                    b.energyCharge(), b.fixedCharge(), b.surcharge(), b.rebate(), b.netPayable(), payment);
            totalUnits += b.units();
            totalSurcharge += b.surcharge();
            totalRebate += b.rebate();
            totalNet += b.netPayable();
        }
        System.out.println("-".repeat(86));
        System.out.printf("Total %6d %30.2f %8.2f %11.2f%n", totalUnits, totalSurcharge, totalRebate, totalNet);
        System.out.printf("Average monthly consumption: %.2f units%n%n", (double) totalUnits / 12);
    }

    /** Task 4 (b) - do-while loop reads meter readings until the user enters 0. */
    static void readMeterReadings(Scanner sc) {
        System.out.println("================ METER READING ENTRY ================");
        Category category = null;
        while (category == null) {
            System.out.print("Consumer category (D = Domestic, C = Commercial, I = Industrial): ");
            try {
                category = Category.fromCode(sc.next().charAt(0));
            } catch (IllegalArgumentException e) {
                System.out.println("  " + e.getMessage() + " - try again.");
            }
        }

        int units;
        int billed = 0;
        double grandTotal = 0.0;
        do {
            System.out.print("Enter units consumed (0 to stop): ");
            if (!sc.hasNextInt()) {
                System.out.println("  Invalid input '" + sc.next() + "' - enter a whole number.");
                units = -1;                    // keeps the loop running
                continue;                      // jumps to the while condition
            }
            units = sc.nextInt();
            if (units < 0) {
                System.out.println("  Units cannot be negative - reading ignored.");
                continue;
            }
            if (units > 0) {
                System.out.print("Days paid after due date (0 if on time): ");
                int daysLate = sc.nextInt();
                System.out.print("Paid online? (y/n): ");
                boolean online = sc.next().equalsIgnoreCase("y");
                Bill bill = BillingCalculator.computeBill(units, category, daysLate, online);
                printBill(bill);
                billed++;
                grandTotal += bill.netPayable();
            }
        } while (units != 0);

        System.out.printf("Readings billed: %d | Total billed: Rs. %.2f%n", billed, grandTotal);
        System.out.println("Meter reading entry closed.");
    }

    static void printBill(Bill b) {
        System.out.println("  ------------------- BILL -------------------");
        System.out.printf("  Units consumed        : %d (%s)%n", b.units(), b.category());
        System.out.printf("  Slab breakdown        : %s%n", BillingCalculator.slabBreakdown(b.units()));
        System.out.printf("  Energy charge         : Rs. %9.2f%n", b.energyCharge());
        System.out.printf("  Fixed charge          : Rs. %9.2f%n", b.fixedCharge());
        System.out.printf("  Late surcharge (2%%)   : Rs. %9.2f%n", b.surcharge());
        System.out.printf("  Online rebate (1%%)    : Rs. %9.2f%n", b.rebate() == 0 ? 0.0 : -b.rebate());
        System.out.printf("  NET AMOUNT PAYABLE    : Rs. %9.2f%n", b.netPayable());
        System.out.println("  --------------------------------------------");
    }
}
