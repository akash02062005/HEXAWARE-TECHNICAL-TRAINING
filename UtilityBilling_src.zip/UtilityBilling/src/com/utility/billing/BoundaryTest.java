package com.utility.billing;

/** Boundary value tests for the slab edges 100/101, 200/201 and 400/401. */
public class BoundaryTest {

    public static void main(String[] args) {
        int[]    units    = {0, 100, 101, 200, 201, 400, 401};
        double[] expected = {0.00, 300.00, 304.50, 750.00, 756.00, 1950.00, 1957.50};
        int passed = 0;

        System.out.printf("%-6s %-46s %10s %10s  %s%n", "Units", "Slab breakdown", "Expected", "Actual", "Result");
        System.out.println("-".repeat(86));
        for (int i = 0; i < units.length; i++) {
            double actual = BillingCalculator.energyCharge(units[i]);
            boolean ok = Math.abs(actual - expected[i]) < 0.001;
            if (ok) passed++;
            System.out.printf("%-6d %-46s %10.2f %10.2f  %s%n", units[i],
                    BillingCalculator.slabBreakdown(units[i]), expected[i], actual, ok ? "PASS" : "FAIL");
        }
        System.out.println("-".repeat(86));

        // Full bill at the 401 boundary for every category (fixed charge from the switch expression)
        for (Category c : Category.values()) {
            Bill b = BillingCalculator.computeBill(401, c, 0, false);
            System.out.printf("401 units, %-10s -> energy %.2f + fixed %.2f = Rs. %.2f%n",
                    c, b.energyCharge(), b.fixedCharge(), b.netPayable());
        }

        // Negative reading must be rejected
        try {
            BillingCalculator.energyCharge(-1);
            System.out.println("-1 units  -> FAIL (no exception)");
        } catch (IllegalArgumentException e) {
            passed++;
            System.out.println("-1 units  -> PASS (" + e.getMessage() + ")");
        }
        System.out.println("Boundary tests passed: " + passed + " of " + (units.length + 1));
    }
}
