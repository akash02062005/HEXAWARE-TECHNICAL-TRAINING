package com.utility.billing;

/** Consumer categories served by the distribution company. */
public enum Category {
    DOMESTIC, COMMERCIAL, INDUSTRIAL;

    /** Maps the code typed by the user (D / C / I) to a category - switch expression. */
    public static Category fromCode(char code) {
        return switch (Character.toUpperCase(code)) {
            case 'D' -> DOMESTIC;
            case 'C' -> COMMERCIAL;
            case 'I' -> INDUSTRIAL;
            default  -> throw new IllegalArgumentException("Unknown category code: " + code);
        };
    }
}
