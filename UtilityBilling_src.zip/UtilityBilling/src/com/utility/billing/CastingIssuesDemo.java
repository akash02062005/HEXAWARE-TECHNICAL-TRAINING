package com.utility.billing;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Task 5 - primitive casting issues seen in billing code, and the correct handling. */
public class CastingIssuesDemo {

    public static void main(String[] args) {
        // ---------- 1. Integer division ----------
        System.out.println("1. INTEGER DIVISION");
        int monthlyUnits = 250, daysInCycle = 30;
        double wrongAvg = monthlyUnits / daysInCycle;            // int / int = 8, then widened
        double rightAvg = (double) monthlyUnits / daysInCycle;   // cast one operand first
        System.out.println("   Wrong : 250 / 30           = " + wrongAvg);
        System.out.println("   Right : (double) 250 / 30  = " + String.format("%.4f", rightAvg));

        int surchargePercent = 2;
        double wrongSurcharge = surchargePercent / 100 * 1500.0; // 2 / 100 = 0 -> 0.0
        double rightSurcharge = surchargePercent / 100.0 * 1500.0;
        System.out.println("   Wrong : 2 / 100 * 1500.0   = " + wrongSurcharge);
        System.out.println("   Right : 2 / 100.0 * 1500.0 = " + rightSurcharge);

        // ---------- 2. Integer overflow ----------
        System.out.println("\n2. INTEGER OVERFLOW");
        int annualUnits = 3_000_000;                              // large industrial consumer (kWh)
        int wrongWh = annualUnits * 1000;                         // 3e9 > Integer.MAX_VALUE
        long rightWh = annualUnits * 1000L;                       // long arithmetic
        System.out.println("   Integer.MAX_VALUE          = " + Integer.MAX_VALUE);
        System.out.println("   Wrong : int  3,000,000 * 1000  = " + wrongWh);
        System.out.println("   Right : long 3,000,000 * 1000L = " + rightWh);
        try {
            Math.multiplyExact(annualUnits, 1000);                // fails loudly instead
        } catch (ArithmeticException e) {
            System.out.println("   Safe  : Math.multiplyExact -> ArithmeticException: " + e.getMessage());
        }

        // ---------- 3. double to int ----------
        System.out.println("\n3. DOUBLE TO INT");
        double netBill = 1957.89;
        int truncated = (int) netBill;                            // drops the fraction
        long rounded = Math.round(netBill);                       // nearest rupee
        System.out.println("   Wrong : (int) 1957.89          = " + truncated + "  (89 paise lost)");
        System.out.println("   Right : Math.round(1957.89)    = " + rounded);
        System.out.println("   (int) -7.8 = " + (int) -7.8 + "   Math.round(-7.8) = " + Math.round(-7.8));
        System.out.println("   (int) 3.0E10 = " + (int) 3.0E10 + "  (clamped to Integer.MAX_VALUE)");
        System.out.println("   (byte) 200   = " + (byte) 200 + "  (narrowing keeps only the low 8 bits)");

        // ---------- 4. Money in double vs BigDecimal ----------
        System.out.println("\n4. MONEY: double vs BigDecimal");
        double d = 0.10 + 0.20;
        BigDecimal bd = new BigDecimal("0.10").add(new BigDecimal("0.20"));
        System.out.println("   double     0.10 + 0.20 = " + d);
        System.out.println("   BigDecimal 0.10 + 0.20 = " + bd);
        BigDecimal rebate = new BigDecimal("1957.50").multiply(new BigDecimal("0.01"))
                                                    .setScale(2, RoundingMode.HALF_UP);
        System.out.println("   1% rebate on Rs. 1957.50 (HALF_UP) = Rs. " + rebate);
    }
}
