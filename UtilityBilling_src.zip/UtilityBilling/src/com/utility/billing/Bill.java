package com.utility.billing;

/** Immutable result of one billing calculation (all amounts in rupees). */
public record Bill(int units, Category category, double energyCharge, double fixedCharge,
                   double surcharge, double rebate, double netPayable) {
}
